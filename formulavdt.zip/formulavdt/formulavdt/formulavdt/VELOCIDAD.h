#pragma once

class VELOCIDAD
{
	//Atributos
private:
	int distancia;
	int tiempo; 
	int velocidad;

public: //Metodos

	VELOCIDAD(void); //Constructor
	// Metodos de acceso
	int Get_tiempo();
	int Get_distancia();
	int Get_velocidad();

	//Para darle valor a los atributos
	void Set_tiempo(int t);
	void Set_distancia(int d);
	void Set_velocidad(int v);

	//Operaciones especificas
	int Calcular();


};

