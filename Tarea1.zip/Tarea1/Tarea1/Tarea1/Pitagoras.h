#pragma once
 class Pitagoras
{
private:
	float hipotenusa;
	float catetoa;
	float catetob;
public:
	Pitagoras(void);
	float Get_hipotenusa();
	float Get_catetoa();
	float Get_catetob();
	void Set_hipotenusa(int h);
	void Set_catetoa(int ca);
	void Set_catetob(int cb);

	float Calcular();
	float CalcularA();
	float CalcularB();
};

