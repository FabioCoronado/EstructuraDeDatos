#include "StdAfx.h"
#include "Pitagoras.h"
#include <cmath>

Pitagoras::Pitagoras(void)
{
}
float Pitagoras::Get_hipotenusa()
{
	return hipotenusa;
}
float Pitagoras::Get_catetoa()
{
	return catetoa;
}
float Pitagoras::Get_catetob()
{
	return catetob;
}
void Pitagoras::Set_hipotenusa(int h)
{
	hipotenusa=h;
}
void Pitagoras::Set_catetoa(int ca)
{
	catetoa=ca;
}
void Pitagoras::Set_catetob(int cb)
{
	catetob=cb;
}

float Pitagoras::Calcular()
{
	hipotenusa=sqrt(((catetoa*catetoa))+((catetob*catetob)));
	return hipotenusa;
}
float Pitagoras::CalcularA()
{
	catetoa=sqrt(((hipotenusa*hipotenusa))-((catetob*catetob)));
	return catetoa;
}
float Pitagoras::CalcularB()
{
	catetob=sqrt(((hipotenusa*hipotenusa))-((catetoa*catetoa)));
	return catetob;
}