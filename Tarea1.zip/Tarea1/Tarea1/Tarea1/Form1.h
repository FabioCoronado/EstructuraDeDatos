#pragma once
#include <iostream>
#include "Pitagoras.h"
#include "msclr/marshal_cppstd.h"
namespace Tarea1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtCA;
	private: System::Windows::Forms::TextBox^  txtCB;
	private: System::Windows::Forms::TextBox^  txtH;
	private: System::Windows::Forms::Button^  btnCalcular;
	private: System::Windows::Forms::Button^  btnCA;
	private: System::Windows::Forms::Button^  btnCB;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtCA = (gcnew System::Windows::Forms::TextBox());
			this->txtCB = (gcnew System::Windows::Forms::TextBox());
			this->txtH = (gcnew System::Windows::Forms::TextBox());
			this->btnCalcular = (gcnew System::Windows::Forms::Button());
			this->btnCA = (gcnew System::Windows::Forms::Button());
			this->btnCB = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(37, 45);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(48, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Cateto A";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(37, 92);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(48, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Cateto B";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(33, 150);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(64, 13);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Hipotenusa ";
			// 
			// txtCA
			// 
			this->txtCA->Location = System::Drawing::Point(159, 42);
			this->txtCA->Name = L"txtCA";
			this->txtCA->Size = System::Drawing::Size(100, 20);
			this->txtCA->TabIndex = 3;
			// 
			// txtCB
			// 
			this->txtCB->Location = System::Drawing::Point(159, 89);
			this->txtCB->Name = L"txtCB";
			this->txtCB->Size = System::Drawing::Size(100, 20);
			this->txtCB->TabIndex = 4;
			// 
			// txtH
			// 
			this->txtH->Location = System::Drawing::Point(159, 147);
			this->txtH->Name = L"txtH";
			this->txtH->Size = System::Drawing::Size(100, 20);
			this->txtH->TabIndex = 5;
			// 
			// btnCalcular
			// 
			this->btnCalcular->Location = System::Drawing::Point(51, 207);
			this->btnCalcular->Name = L"btnCalcular";
			this->btnCalcular->Size = System::Drawing::Size(75, 27);
			this->btnCalcular->TabIndex = 6;
			this->btnCalcular->Text = L"Calcular H";
			this->btnCalcular->UseVisualStyleBackColor = true;
			this->btnCalcular->Click += gcnew System::EventHandler(this, &Form1::btnCalcular_Click);
			// 
			// btnCA
			// 
			this->btnCA->Location = System::Drawing::Point(159, 207);
			this->btnCA->Name = L"btnCA";
			this->btnCA->Size = System::Drawing::Size(75, 27);
			this->btnCA->TabIndex = 7;
			this->btnCA->Text = L"Calcular A";
			this->btnCA->UseVisualStyleBackColor = true;
			this->btnCA->Click += gcnew System::EventHandler(this, &Form1::btnCA_Click);
			// 
			// btnCB
			// 
			this->btnCB->Location = System::Drawing::Point(269, 207);
			this->btnCB->Name = L"btnCB";
			this->btnCB->Size = System::Drawing::Size(77, 27);
			this->btnCB->TabIndex = 8;
			this->btnCB->Text = L"Calcular B";
			this->btnCB->UseVisualStyleBackColor = true;
			this->btnCB->Click += gcnew System::EventHandler(this, &Form1::btnCB_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(383, 261);
			this->Controls->Add(this->btnCB);
			this->Controls->Add(this->btnCA);
			this->Controls->Add(this->btnCalcular);
			this->Controls->Add(this->txtH);
			this->Controls->Add(this->txtCB);
			this->Controls->Add(this->txtCA);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
				 Pitagoras hipo;
				 hipo.Set_catetoa(System::Convert::ToDouble(txtCA->Text));
				 hipo.Set_catetob(System::Convert::ToDouble(txtCB->Text));
				 float hipofin;
				 hipofin=hipo.Calcular();
				 txtH->Text=System::Convert::ToString(hipofin);
			 }
private: System::Void btnCA_Click(System::Object^  sender, System::EventArgs^  e) {
			 Pitagoras caa;
				 caa.Set_hipotenusa(System::Convert::ToDouble(txtH->Text));
				 caa.Set_catetob(System::Convert::ToDouble(txtCB->Text));
				 float caafin;
				 caafin=caa.CalcularA();
				 txtCA->Text=System::Convert::ToString(caafin);
		 }
private: System::Void btnCB_Click(System::Object^  sender, System::EventArgs^  e) {
			  Pitagoras cbb;
				 cbb.Set_hipotenusa(System::Convert::ToDouble(txtH->Text));
				 cbb.Set_catetoa(System::Convert::ToDouble(txtCA->Text));
				 float cbbfin;
				 cbbfin=cbb.CalcularB();
				 txtCB->Text=System::Convert::ToString(cbbfin);
		 }
};
}

