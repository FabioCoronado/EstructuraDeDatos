#pragma once

namespace holamundo {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblhola;
	private: System::Windows::Forms::Button^  btnhola;
	private: System::Windows::Forms::TextBox^  txtmensaje;
	protected: 

	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->lblhola = (gcnew System::Windows::Forms::Label());
			this->btnhola = (gcnew System::Windows::Forms::Button());
			this->txtmensaje = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// lblhola
			// 
			this->lblhola->AutoSize = true;
			this->lblhola->BackColor = System::Drawing::SystemColors::Control;
			this->lblhola->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 27.75F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->lblhola->ForeColor = System::Drawing::SystemColors::ButtonFace;
			this->lblhola->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"lblhola.Image")));
			this->lblhola->Location = System::Drawing::Point(110, 97);
			this->lblhola->MaximumSize = System::Drawing::Size(300, 300);
			this->lblhola->MinimumSize = System::Drawing::Size(100, 80);
			this->lblhola->Name = L"lblhola";
			this->lblhola->Size = System::Drawing::Size(230, 80);
			this->lblhola->TabIndex = 0;
			this->lblhola->Text = L"Hola Mundo";
			this->lblhola->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			this->lblhola->Click += gcnew System::EventHandler(this, &Form1::label1_Click);
			// 
			// btnhola
			// 
			this->btnhola->Location = System::Drawing::Point(151, 210);
			this->btnhola->Name = L"btnhola";
			this->btnhola->Size = System::Drawing::Size(136, 34);
			this->btnhola->TabIndex = 1;
			this->btnhola->Text = L"Mensaje";
			this->btnhola->UseVisualStyleBackColor = true;
			this->btnhola->Click += gcnew System::EventHandler(this, &Form1::btnhola_Click);
			// 
			// txtmensaje
			// 
			this->txtmensaje->Location = System::Drawing::Point(130, 39);
			this->txtmensaje->Name = L"txtmensaje";
			this->txtmensaje->Size = System::Drawing::Size(193, 20);
			this->txtmensaje->TabIndex = 2;
			this->txtmensaje->Text = L"                              ";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->ClientSize = System::Drawing::Size(451, 277);
			this->Controls->Add(this->txtmensaje);
			this->Controls->Add(this->btnhola);
			this->Controls->Add(this->lblhola);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 }
	private: System::Void btnhola_Click(System::Object^  sender, System::EventArgs^  e) {
				 txtmensaje->Text="Hola Mundo";
			 }
};
}

